# Changelog for Python Install Cookbook

## 1.2.0

* Fix build of shared libs for Python 3.7
* Improve idempotence of resource by sacrificing robustness of rebuild

## 1.1.0

* Added helpers for default version and path
* Created installer library

## 1.0.0

* Initial release
