Test fixture for the [python_install](https://github.com/ualaska-it/python_install) cookbook.
